const jwt = require('jsonwebtoken');
const prisma = require('../config/db');
const { safeUser } = require('../utils/safeUser');

async function authRequired(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ ok: false, error: 'Unauthorized' });

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await prisma.user.findFirst({ where: { id: payload.id, isActive: true } });
    if (!user) return res.status(401).json({ ok: false, error: 'User inactive or not found' });
    req.user = safeUser(user);
    next();
  } catch (err) {
    return res.status(401).json({ ok: false, error: 'Invalid token' });
  }
}

module.exports = { authRequired };
