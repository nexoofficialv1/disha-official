const router = require('express').Router();
const { z } = require('zod');
const prisma = require('../config/db');
const { authRequired } = require('../middleware/auth');

const providerSchema = z.object({
  displayName: z.string().trim().min(2),
  area: z.string().trim().min(2),
  city: z.string().trim().min(2).default('Kalna'),
  mobile: z.string().regex(/^[6-9]\d{9}$/),
  whatsapp: z.string().regex(/^[6-9]\d{9}$/).optional().or(z.literal('')),
  latitude: z.number().optional().nullable(),
  longitude: z.number().optional().nullable(),
  availableTime: z.string().optional().or(z.literal('')),
  services: z.array(z.object({
    categoryId: z.number().int(),
    title: z.string().trim().min(1),
    price: z.string().optional().or(z.literal('')),
    description: z.string().optional().or(z.literal(''))
  })).min(1)
});

// Specific routes must remain before /:id.
router.get('/me/profile', authRequired, async (req, res, next) => {
  try {
    const data = await prisma.provider.findUnique({
      where: { userId: req.user.id },
      include: { services: { include: { category: true } } }
    });
    res.json({ ok: true, data });
  } catch (err) { next(err); }
});

router.put('/me/profile', authRequired, async (req, res, next) => {
  try {
    const body = providerSchema.parse(req.body);
    const existing = await prisma.provider.findUnique({ where: { userId: req.user.id } });
    let provider;

    if (existing) {
      await prisma.providerService.deleteMany({ where: { providerId: existing.id } });
      provider = await prisma.provider.update({
        where: { id: existing.id },
        data: {
          displayName: body.displayName,
          area: body.area,
          city: body.city,
          mobile: body.mobile,
          whatsapp: body.whatsapp || null,
          latitude: body.latitude,
          longitude: body.longitude,
          availableTime: body.availableTime,
          services: { create: body.services }
        },
        include: { services: { include: { category: true } } }
      });
    } else {
      provider = await prisma.provider.create({
        data: {
          userId: req.user.id,
          displayName: body.displayName,
          area: body.area,
          city: body.city,
          mobile: body.mobile,
          whatsapp: body.whatsapp || null,
          latitude: body.latitude,
          longitude: body.longitude,
          availableTime: body.availableTime,
          services: { create: body.services }
        },
        include: { services: { include: { category: true } } }
      });
    }

    await prisma.user.update({ where: { id: req.user.id }, data: { purpose: 'PROVIDER' } });
    res.json({ ok: true, data: provider });
  } catch (err) { next(err); }
});

router.get('/', async (req, res, next) => {
  try {
    const { city = 'Kalna', q, categoryId, page = '1', limit = '20' } = req.query;
    const take = Math.min(Math.max(Number(limit) || 20, 1), 50);
    const skip = Math.max((Number(page) || 1) - 1, 0) * take;

    const where = { status: 'APPROVED', city: String(city) };
    if (q) {
      where.OR = [
        { displayName: { contains: String(q), mode: 'insensitive' } },
        { area: { contains: String(q), mode: 'insensitive' } },
        { services: { some: { title: { contains: String(q), mode: 'insensitive' } } } }
      ];
    }
    if (categoryId) where.services = { some: { categoryId: Number(categoryId), isActive: true } };

    const data = await prisma.provider.findMany({
      where,
      include: { services: { where: { isActive: true }, include: { category: true } } },
      skip,
      take,
      orderBy: [{ verified: 'desc' }, { updatedAt: 'desc' }]
    });

    res.json({ ok: true, data, page: Number(page) || 1, limit: take });
  } catch (err) { next(err); }
});

router.get('/:id', async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ ok: false, error: 'Invalid provider id' });
    const data = await prisma.provider.findUnique({
      where: { id },
      include: { services: { where: { isActive: true }, include: { category: true } } }
    });
    if (!data || data.status !== 'APPROVED') return res.status(404).json({ ok: false, error: 'Provider not found' });
    res.json({ ok: true, data });
  } catch (err) { next(err); }
});

module.exports = router;
