require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const app = express();
const corsOrigin = process.env.CORS_ORIGIN || '*';

app.use(helmet());
app.use(cors({ origin: corsOrigin === '*' ? true : corsOrigin, credentials: true }));
app.use(express.json({ limit: '2mb' }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(rateLimit({ windowMs: 60 * 1000, max: 120, standardHeaders: true, legacyHeaders: false }));

app.use('/api/health', require('./routes/health.routes'));
app.use('/api/auth', require('./routes/auth.routes'));
app.use('/api/categories', require('./routes/categories.routes'));
app.use('/api/providers', require('./routes/providers.routes'));
app.use('/api/bookings', require('./routes/bookings.routes'));
app.use('/api/chat', require('./routes/chat.routes'));
app.use('/api/legal', require('./routes/legal.routes'));

app.use((req, res) => res.status(404).json({ ok: false, error: 'Route not found' }));
app.use((err, req, res, next) => {
  if (err.name === 'ZodError') {
    return res.status(400).json({ ok: false, error: 'Validation failed', details: err.errors });
  }
  if (err.code === 'P2002') {
    return res.status(409).json({ ok: false, error: 'Duplicate record' });
  }
  console.error(err);
  res.status(err.status || 500).json({ ok: false, error: err.message || 'Server error' });
});

const port = Number(process.env.PORT || 5000);
app.listen(port, () => console.log(`DISHA API running on port ${port}`));
