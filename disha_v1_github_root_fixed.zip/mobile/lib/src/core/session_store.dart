import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class AppSession {
  AppSession({required this.token, required this.userId, required this.name, this.purpose});

  final String token;
  final int userId;
  final String name;
  final String? purpose;

  Map<String, dynamic> toJson() => {
        'token': token,
        'userId': userId,
        'name': name,
        'purpose': purpose,
      };

  factory AppSession.fromJson(Map<String, dynamic> json) => AppSession(
        token: json['token'] as String,
        userId: json['userId'] as int,
        name: json['name'] as String,
        purpose: json['purpose'] as String?,
      );
}

class SessionStore {
  SessionStore._();
  static final instance = SessionStore._();
  static const _key = 'disha_session';

  Future<void> save(AppSession session) async {
    final pref = await SharedPreferences.getInstance();
    await pref.setString(_key, jsonEncode(session.toJson()));
  }

  Future<AppSession?> read() async {
    final pref = await SharedPreferences.getInstance();
    final raw = pref.getString(_key);
    if (raw == null) return null;
    try {
      return AppSession.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      await clear();
      return null;
    }
  }

  Future<void> clear() async {
    final pref = await SharedPreferences.getInstance();
    await pref.remove(_key);
  }
}
