import 'package:flutter/material.dart';

import '../core/api_client.dart';
import '../core/models.dart';
import '../services/provider_service.dart';

class ProviderSetupScreen extends StatefulWidget {
  const ProviderSetupScreen({super.key});

  @override
  State<ProviderSetupScreen> createState() => _ProviderSetupScreenState();
}

class _ProviderSetupScreenState extends State<ProviderSetupScreen> {
  final _api = ProviderServiceApi();
  final _formKey = GlobalKey<FormState>();
  final _displayName = TextEditingController();
  final _area = TextEditingController();
  final _city = TextEditingController(text: 'Kalna');
  final _mobile = TextEditingController();
  final _whatsapp = TextEditingController();
  final _available = TextEditingController();
  final _price = TextEditingController();
  final Set<int> _selected = {};
  List<Category> _categories = [];
  bool _loading = true;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final cats = await _api.categories();
      final profile = await _api.myProfile();
      if (profile != null) {
        _displayName.text = profile.displayName;
        _area.text = profile.area;
        _city.text = profile.city;
        _mobile.text = profile.mobile;
        _whatsapp.text = profile.whatsapp ?? '';
        _available.text = profile.availableTime ?? '';
        for (final s in profile.services) {
          if (s.category != null) _selected.add(s.category!.id);
          if ((s.price ?? '').isNotEmpty && _price.text.isEmpty) _price.text = s.price!;
        }
      }
      setState(() => _categories = cats);
    } catch (e) {
      setState(() => _error = apiError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selected.isEmpty) {
      setState(() => _error = 'কমপক্ষে একটি service select করুন');
      return;
    }
    setState(() { _saving = true; _error = null; });
    try {
      final services = _categories.where((c) => _selected.contains(c.id)).map((c) => {
        'categoryId': c.id,
        'title': c.nameBn,
        'price': _price.text.trim(),
        'description': '',
      }).toList();
      await _api.saveProfile({
        'displayName': _displayName.text.trim(),
        'area': _area.text.trim(),
        'city': _city.text.trim(),
        'mobile': _mobile.text.trim(),
        'whatsapp': _whatsapp.text.trim(),
        'availableTime': _available.text.trim(),
        'services': services,
      });
      if (mounted) Navigator.pushReplacementNamed(context, '/home');
    } catch (e) {
      setState(() => _error = apiError(e));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Provider Profile')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(18),
                children: [
                  const Text('আপনার পরিষেবা তথ্য', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 14),
                  TextFormField(controller: _displayName, decoration: const InputDecoration(labelText: 'Business/Display Name'), validator: (v) => v == null || v.trim().length < 2 ? 'Required' : null),
                  const SizedBox(height: 12),
                  TextFormField(controller: _area, decoration: const InputDecoration(labelText: 'Area'), validator: (v) => v == null || v.trim().length < 2 ? 'Required' : null),
                  const SizedBox(height: 12),
                  TextFormField(controller: _city, decoration: const InputDecoration(labelText: 'City'), validator: (v) => v == null || v.trim().length < 2 ? 'Required' : null),
                  const SizedBox(height: 12),
                  TextFormField(controller: _mobile, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Mobile'), validator: (v) => v == null || !RegExp(r'^[6-9]\d{9}$').hasMatch(v.trim()) ? 'Valid mobile required' : null),
                  const SizedBox(height: 12),
                  TextFormField(controller: _whatsapp, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'WhatsApp optional')),
                  const SizedBox(height: 12),
                  TextFormField(controller: _available, decoration: const InputDecoration(labelText: 'Available Time')),
                  const SizedBox(height: 12),
                  TextFormField(controller: _price, decoration: const InputDecoration(labelText: 'Starting Price / Rate')),
                  const SizedBox(height: 18),
                  const Text('Services', style: TextStyle(fontWeight: FontWeight.w900)),
                  ..._categories.map((c) => CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    value: _selected.contains(c.id),
                    title: Text('${c.icon ?? ''} ${c.nameBn}'),
                    onChanged: (v) => setState(() => v == true ? _selected.add(c.id) : _selected.remove(c.id)),
                  )),
                  if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
                  const SizedBox(height: 10),
                  FilledButton(onPressed: _saving ? null : _save, child: Text(_saving ? 'Saving...' : 'Save Provider Profile')),
                ],
              ),
            ),
    );
  }
}
