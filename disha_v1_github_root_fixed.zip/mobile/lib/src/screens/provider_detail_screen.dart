import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/api_client.dart';
import '../core/models.dart';
import '../services/booking_service.dart';
import '../services/provider_service.dart';
import 'chat_screen.dart';

class ProviderDetailScreen extends StatefulWidget {
  const ProviderDetailScreen({super.key, required this.providerId});
  final int providerId;

  @override
  State<ProviderDetailScreen> createState() => _ProviderDetailScreenState();
}

class _ProviderDetailScreenState extends State<ProviderDetailScreen> {
  ProviderItem? _provider;
  bool _loading = true;
  bool _booking = false;
  String? _error;
  DateTime? _date;
  String? _service;
  final _note = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final p = await ProviderServiceApi().provider(widget.providerId);
      setState(() { _provider = p; _service = p.services.isNotEmpty ? p.services.first.title : null; });
    } catch (e) {
      setState(() => _error = apiError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _launch(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Unable to open')));
    }
  }

  Future<void> _book() async {
    if (_provider == null || _service == null || _date == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Service এবং date select করুন')));
      return;
    }
    setState(() => _booking = true);
    try {
      await BookingServiceApi().create(providerId: _provider!.id, serviceName: _service!, date: _date!, note: _note.text.trim());
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Booking request sent')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(apiError(e))));
    } finally {
      if (mounted) setState(() => _booking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = _provider;
    return Scaffold(
      appBar: AppBar(title: const Text('Provider Details')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : p == null
                  ? const Center(child: Text('Provider not found'))
                  : ListView(
                      padding: const EdgeInsets.all(18),
                      children: [
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(18),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(p.displayName, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
                              Text('${p.area}, ${p.city}'),
                              if ((p.availableTime ?? '').isNotEmpty) Text('Available: ${p.availableTime}'),
                              const SizedBox(height: 14),
                              Wrap(spacing: 8, children: p.services.map((s) => Chip(label: Text('${s.category?.icon ?? ''} ${s.title}${(s.price ?? '').isEmpty ? '' : ' · ${s.price}'}'))).toList()),
                            ]),
                          ),
                        ),
                        Row(children: [
                          Expanded(child: OutlinedButton.icon(onPressed: () => _launch('tel:${p.mobile}'), icon: const Icon(Icons.call), label: const Text('Call'))),
                          const SizedBox(width: 8),
                          Expanded(child: OutlinedButton.icon(onPressed: () => _launch('https://wa.me/91${p.whatsapp ?? p.mobile}'), icon: const Icon(Icons.chat), label: const Text('WhatsApp'))),
                        ]),
                        OutlinedButton.icon(onPressed: () => _launch('https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent('${p.displayName} ${p.area} ${p.city}')}'), icon: const Icon(Icons.directions), label: const Text('Direction')),
                        OutlinedButton.icon(onPressed: () => Navigator.pushNamed(context, '/chat', arguments: ChatScreenArgs(providerId: p.id, providerName: p.displayName)), icon: const Icon(Icons.message), label: const Text('In-app Chat')),
                        const SizedBox(height: 18),
                        const Text('Booking Request', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 8),
                        DropdownButtonFormField<String>(
                          value: _service,
                          decoration: const InputDecoration(labelText: 'Service'),
                          items: p.services.map((s) => DropdownMenuItem(value: s.title, child: Text(s.title))).toList(),
                          onChanged: (v) => setState(() => _service = v),
                        ),
                        const SizedBox(height: 12),
                        OutlinedButton.icon(
                          onPressed: () async {
                            final picked = await showDatePicker(context: context, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 60)), initialDate: DateTime.now());
                            if (picked != null) setState(() => _date = DateTime(picked.year, picked.month, picked.day, 10));
                          },
                          icon: const Icon(Icons.calendar_month),
                          label: Text(_date == null ? 'Select Date' : '${_date!.day}-${_date!.month}-${_date!.year}'),
                        ),
                        const SizedBox(height: 12),
                        TextField(controller: _note, minLines: 2, maxLines: 4, decoration: const InputDecoration(labelText: 'Note optional')),
                        const SizedBox(height: 12),
                        FilledButton(onPressed: _booking ? null : _book, child: Text(_booking ? 'Sending...' : 'Send Booking Request')),
                      ],
                    ),
    );
  }
}
