import 'package:flutter/material.dart';

import '../core/api_client.dart';
import '../services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _identifier = TextEditingController();
  final _password = TextEditingController();
  bool _isRegister = true;
  bool _accepted = false;
  bool _loading = false;
  String? _error;

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_isRegister && !_accepted) {
      setState(() => _error = 'Privacy Policy ও Terms accept করতে হবে');
      return;
    }
    setState(() { _loading = true; _error = null; });
    try {
      final auth = AuthService();
      if (_isRegister) {
        final input = _identifier.text.trim();
        final isMobile = RegExp(r'^[6-9]\d{9}$').hasMatch(input);
        await auth.register(
          name: _name.text.trim(),
          email: isMobile ? null : input,
          mobile: isMobile ? input : null,
          password: _password.text,
          termsAccepted: _accepted,
        );
      } else {
        await auth.login(identifier: _identifier.text.trim(), password: _password.text);
      }
      if (mounted) Navigator.pushReplacementNamed(context, '/purpose');
    } catch (e) {
      setState(() => _error = apiError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isRegister ? 'Create DISHA Account' : 'Login')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            const Text('DISHA', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900)),
            const Text('Local Services OS · Powered by ASTRA Technologies'),
            const SizedBox(height: 24),
            if (_isRegister)
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'Name'),
                validator: (v) => (v == null || v.trim().length < 2) ? 'Name required' : null,
              ),
            if (_isRegister) const SizedBox(height: 12),
            TextFormField(
              controller: _identifier,
              decoration: const InputDecoration(labelText: 'Email or Mobile'),
              validator: (v) => (v == null || v.trim().length < 3) ? 'Email or mobile required' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _password,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Password'),
              validator: (v) => (v == null || v.length < 6) ? 'Minimum 6 characters' : null,
            ),
            if (_isRegister)
              CheckboxListTile(
                value: _accepted,
                onChanged: (v) => setState(() => _accepted = v ?? false),
                title: const Text('I agree to Privacy Policy and Terms & Conditions'),
                contentPadding: EdgeInsets.zero,
              ),
            if (_error != null) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(_error!, style: const TextStyle(color: Colors.red))),
            FilledButton(onPressed: _loading ? null : _submit, child: Text(_loading ? 'Please wait...' : (_isRegister ? 'Register' : 'Login'))),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () => setState(() { _isRegister = !_isRegister; _error = null; }),
              child: Text(_isRegister ? 'Already have account? Login' : 'New user? Register'),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextButton(onPressed: () => Navigator.pushNamed(context, '/privacy'), child: const Text('Privacy')),
                TextButton(onPressed: () => Navigator.pushNamed(context, '/terms'), child: const Text('Terms')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
