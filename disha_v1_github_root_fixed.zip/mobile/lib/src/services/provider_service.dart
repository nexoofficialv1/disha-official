import '../core/api_client.dart';
import '../core/models.dart';

class ProviderServiceApi {
  final _dio = ApiClient.instance.dio;

  Future<List<Category>> categories() async {
    final res = await _dio.get('/categories');
    return ((res.data['data'] as List?) ?? []).map((e) => Category.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<List<ProviderItem>> providers({String? q, int? categoryId}) async {
    final res = await _dio.get('/providers', queryParameters: {'q': q, 'categoryId': categoryId});
    return ((res.data['data'] as List?) ?? []).map((e) => ProviderItem.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<ProviderItem> provider(int id) async {
    final res = await _dio.get('/providers/$id');
    return ProviderItem.fromJson(res.data['data'] as Map<String, dynamic>);
  }

  Future<ProviderItem?> myProfile() async {
    final res = await _dio.get('/providers/me/profile');
    final data = res.data['data'];
    if (data == null) return null;
    return ProviderItem.fromJson(data as Map<String, dynamic>);
  }

  Future<void> saveProfile(Map<String, dynamic> data) async {
    await _dio.put('/providers/me/profile', data: data);
  }
}
