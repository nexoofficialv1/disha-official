import '../core/api_client.dart';
import '../core/models.dart';

class BookingServiceApi {
  final _dio = ApiClient.instance.dio;

  Future<void> create({required int providerId, required String serviceName, required DateTime date, String? note}) async {
    await _dio.post('/bookings', data: {
      'providerId': providerId,
      'serviceName': serviceName,
      'date': date.toUtc().toIso8601String(),
      'note': note ?? '',
    });
  }

  Future<List<BookingItem>> mine() async {
    final res = await _dio.get('/bookings/me');
    return ((res.data['data'] as List?) ?? []).map((e) => BookingItem.fromJson(e as Map<String, dynamic>)).toList();
  }
}
